# CBC_estimator

Implementation of an NPE approach to gravitational wave parameter estimation